--
-- PostgreSQL database dump
--

\restrict 4FMyVCxg9gaXauIlxjCESDN6T9AenG3BVSFtDsX4QTvCttHtCBtbPjnJJpdvlOp

-- Dumped from database version 17.7 (Debian 17.7-3.pgdg13+1)
-- Dumped by pg_dump version 17.7 (Debian 17.7-3.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: scraper
--

CREATE TABLE public.categories (
    id bigint NOT NULL,
    platform character varying(50) NOT NULL,
    title character varying(500) NOT NULL,
    title_ru character varying(500),
    title_uz character varying(500),
    parent_id bigint,
    level integer NOT NULL,
    path_ids bigint[],
    path_titles text,
    product_count integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.categories OWNER TO scraper;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: scraper
--

CREATE SEQUENCE public.categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categories_id_seq OWNER TO scraper;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: scraper
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: ecommerce_categories; Type: TABLE; Schema: public; Owner: scraper
--

CREATE TABLE public.ecommerce_categories (
    id bigint NOT NULL,
    platform character varying(20) NOT NULL,
    external_id character varying(100) NOT NULL,
    name character varying(500) NOT NULL,
    name_ru character varying(500),
    name_uz character varying(500),
    name_en character varying(500),
    parent_id bigint,
    level integer NOT NULL,
    path_ids bigint[],
    path_names text,
    product_count integer NOT NULL,
    active_product_count integer NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    attributes jsonb
);


ALTER TABLE public.ecommerce_categories OWNER TO scraper;

--
-- Name: ecommerce_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: scraper
--

CREATE SEQUENCE public.ecommerce_categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ecommerce_categories_id_seq OWNER TO scraper;

--
-- Name: ecommerce_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: scraper
--

ALTER SEQUENCE public.ecommerce_categories_id_seq OWNED BY public.ecommerce_categories.id;


--
-- Name: ecommerce_offers; Type: TABLE; Schema: public; Owner: scraper
--

CREATE TABLE public.ecommerce_offers (
    id bigint NOT NULL,
    platform character varying(20) NOT NULL,
    external_id character varying(100),
    product_id bigint NOT NULL,
    seller_id bigint NOT NULL,
    price numeric(18,2) NOT NULL,
    old_price numeric(18,2),
    currency character varying(10) NOT NULL,
    discount_percent numeric(5,2),
    is_available boolean NOT NULL,
    stock_quantity integer,
    available_amount integer NOT NULL,
    variant_title character varying(500),
    variant_attributes jsonb,
    barcode character varying(100),
    shipping_cost numeric(10,2),
    delivery_days integer,
    first_seen_at timestamp without time zone NOT NULL,
    last_seen_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    scraped_at timestamp without time zone NOT NULL,
    characteristics jsonb
);


ALTER TABLE public.ecommerce_offers OWNER TO scraper;

--
-- Name: ecommerce_offers_id_seq; Type: SEQUENCE; Schema: public; Owner: scraper
--

CREATE SEQUENCE public.ecommerce_offers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ecommerce_offers_id_seq OWNER TO scraper;

--
-- Name: ecommerce_offers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: scraper
--

ALTER SEQUENCE public.ecommerce_offers_id_seq OWNED BY public.ecommerce_offers.id;


--
-- Name: ecommerce_price_history; Type: TABLE; Schema: public; Owner: scraper
--

CREATE TABLE public.ecommerce_price_history (
    id bigint NOT NULL,
    offer_id bigint NOT NULL,
    price numeric(18,2) NOT NULL,
    old_price numeric(18,2),
    currency character varying(10) NOT NULL,
    discount_percent numeric(5,2),
    available_amount integer NOT NULL,
    is_available boolean NOT NULL,
    price_change numeric(18,2),
    price_change_percent numeric(5,2),
    recorded_at timestamp without time zone NOT NULL,
    is_significant_change boolean NOT NULL,
    change_reason character varying(100)
);


ALTER TABLE public.ecommerce_price_history OWNER TO scraper;

--
-- Name: ecommerce_price_history_id_seq; Type: SEQUENCE; Schema: public; Owner: scraper
--

CREATE SEQUENCE public.ecommerce_price_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ecommerce_price_history_id_seq OWNER TO scraper;

--
-- Name: ecommerce_price_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: scraper
--

ALTER SEQUENCE public.ecommerce_price_history_id_seq OWNED BY public.ecommerce_price_history.id;


--
-- Name: ecommerce_products; Type: TABLE; Schema: public; Owner: scraper
--

CREATE TABLE public.ecommerce_products (
    id bigint NOT NULL,
    platform character varying(20) NOT NULL,
    external_id character varying(100) NOT NULL,
    title text NOT NULL,
    title_normalized character varying(1000),
    title_ru text,
    title_uz text,
    title_en text,
    description text,
    category_id bigint,
    seller_id bigint,
    rating numeric(3,2),
    review_count integer NOT NULL,
    order_count integer NOT NULL,
    view_count integer NOT NULL,
    is_available boolean NOT NULL,
    total_available integer NOT NULL,
    min_price numeric(18,2),
    max_price numeric(18,2),
    currency character varying(10) NOT NULL,
    images jsonb,
    video_url text,
    brand character varying(200),
    model character varying(200),
    sku character varying(100),
    barcode character varying(100),
    is_eco boolean NOT NULL,
    is_adult boolean NOT NULL,
    is_perishable boolean NOT NULL,
    has_warranty boolean NOT NULL,
    warranty_info text,
    tags character varying[],
    search_keywords character varying[],
    first_seen_at timestamp without time zone NOT NULL,
    last_seen_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    last_price_check timestamp without time zone,
    attributes jsonb,
    characteristics jsonb,
    raw_data jsonb
);


ALTER TABLE public.ecommerce_products OWNER TO scraper;

--
-- Name: ecommerce_products_id_seq; Type: SEQUENCE; Schema: public; Owner: scraper
--

CREATE SEQUENCE public.ecommerce_products_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ecommerce_products_id_seq OWNER TO scraper;

--
-- Name: ecommerce_products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: scraper
--

ALTER SEQUENCE public.ecommerce_products_id_seq OWNED BY public.ecommerce_products.id;


--
-- Name: ecommerce_sellers; Type: TABLE; Schema: public; Owner: scraper
--

CREATE TABLE public.ecommerce_sellers (
    id bigint NOT NULL,
    platform character varying(20) NOT NULL,
    external_id character varying(100) NOT NULL,
    name character varying(500) NOT NULL,
    link character varying(500),
    description text,
    rating numeric(3,2),
    review_count integer NOT NULL,
    order_count integer NOT NULL,
    total_products integer NOT NULL,
    is_official boolean NOT NULL,
    is_verified boolean NOT NULL,
    is_active boolean NOT NULL,
    registration_date timestamp without time zone,
    profile_url text,
    contact_info jsonb,
    first_seen_at timestamp without time zone NOT NULL,
    last_seen_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    attributes jsonb,
    raw_data jsonb
);


ALTER TABLE public.ecommerce_sellers OWNER TO scraper;

--
-- Name: ecommerce_sellers_id_seq; Type: SEQUENCE; Schema: public; Owner: scraper
--

CREATE SEQUENCE public.ecommerce_sellers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ecommerce_sellers_id_seq OWNER TO scraper;

--
-- Name: ecommerce_sellers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: scraper
--

ALTER SEQUENCE public.ecommerce_sellers_id_seq OWNED BY public.ecommerce_sellers.id;


--
-- Name: price_history; Type: TABLE; Schema: public; Owner: scraper
--

CREATE TABLE public.price_history (
    id bigint NOT NULL,
    sku_id bigint NOT NULL,
    product_id bigint NOT NULL,
    full_price bigint,
    purchase_price bigint,
    discount_percent numeric(5,2),
    available_amount integer NOT NULL,
    recorded_at timestamp without time zone NOT NULL,
    price_change bigint,
    price_change_percent numeric(5,2)
);


ALTER TABLE public.price_history OWNER TO scraper;

--
-- Name: price_history_id_seq; Type: SEQUENCE; Schema: public; Owner: scraper
--

CREATE SEQUENCE public.price_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.price_history_id_seq OWNER TO scraper;

--
-- Name: price_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: scraper
--

ALTER SEQUENCE public.price_history_id_seq OWNED BY public.price_history.id;


--
-- Name: product_sellers; Type: TABLE; Schema: public; Owner: scraper
--

CREATE TABLE public.product_sellers (
    id bigint NOT NULL,
    product_title_normalized character varying(1000),
    barcode character varying(100),
    product_id bigint NOT NULL,
    seller_id bigint NOT NULL,
    min_price bigint,
    max_price bigint,
    first_seen_at timestamp without time zone NOT NULL,
    last_seen_at timestamp without time zone NOT NULL
);


ALTER TABLE public.product_sellers OWNER TO scraper;

--
-- Name: product_sellers_id_seq; Type: SEQUENCE; Schema: public; Owner: scraper
--

CREATE SEQUENCE public.product_sellers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.product_sellers_id_seq OWNER TO scraper;

--
-- Name: product_sellers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: scraper
--

ALTER SEQUENCE public.product_sellers_id_seq OWNED BY public.product_sellers.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: scraper
--

CREATE TABLE public.products (
    id bigint NOT NULL,
    platform character varying(50) NOT NULL,
    title character varying(1000) NOT NULL,
    title_normalized character varying(1000),
    title_ru character varying(1000),
    title_uz character varying(1000),
    category_id bigint,
    seller_id bigint,
    rating numeric(2,1),
    review_count integer NOT NULL,
    order_count integer NOT NULL,
    is_available boolean NOT NULL,
    total_available integer NOT NULL,
    description text,
    photos jsonb,
    video_url text,
    attributes jsonb,
    characteristics jsonb,
    tags character varying[],
    is_eco boolean NOT NULL,
    is_adult boolean NOT NULL,
    is_perishable boolean NOT NULL,
    has_warranty boolean NOT NULL,
    warranty_info text,
    first_seen_at timestamp without time zone NOT NULL,
    last_seen_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    raw_data jsonb
);


ALTER TABLE public.products OWNER TO scraper;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: scraper
--

CREATE SEQUENCE public.products_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.products_id_seq OWNER TO scraper;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: scraper
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: raw_snapshots; Type: TABLE; Schema: public; Owner: scraper
--

CREATE TABLE public.raw_snapshots (
    id bigint NOT NULL,
    platform character varying(50) NOT NULL,
    product_id bigint NOT NULL,
    raw_json jsonb NOT NULL,
    file_path text,
    fetched_at timestamp without time zone NOT NULL,
    processed boolean NOT NULL,
    processed_at timestamp without time zone
);


ALTER TABLE public.raw_snapshots OWNER TO scraper;

--
-- Name: raw_snapshots_id_seq; Type: SEQUENCE; Schema: public; Owner: scraper
--

CREATE SEQUENCE public.raw_snapshots_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.raw_snapshots_id_seq OWNER TO scraper;

--
-- Name: raw_snapshots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: scraper
--

ALTER SEQUENCE public.raw_snapshots_id_seq OWNED BY public.raw_snapshots.id;


--
-- Name: sellers; Type: TABLE; Schema: public; Owner: scraper
--

CREATE TABLE public.sellers (
    id bigint NOT NULL,
    platform character varying(50) NOT NULL,
    title character varying(500) NOT NULL,
    link character varying(255),
    description text,
    rating numeric(2,1),
    review_count integer NOT NULL,
    order_count integer NOT NULL,
    total_products integer NOT NULL,
    is_official boolean NOT NULL,
    registration_date timestamp without time zone,
    account_id bigint,
    first_seen_at timestamp without time zone NOT NULL,
    last_seen_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    raw_data jsonb
);


ALTER TABLE public.sellers OWNER TO scraper;

--
-- Name: sellers_id_seq; Type: SEQUENCE; Schema: public; Owner: scraper
--

CREATE SEQUENCE public.sellers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sellers_id_seq OWNER TO scraper;

--
-- Name: sellers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: scraper
--

ALTER SEQUENCE public.sellers_id_seq OWNED BY public.sellers.id;


--
-- Name: skus; Type: TABLE; Schema: public; Owner: scraper
--

CREATE TABLE public.skus (
    id bigint NOT NULL,
    product_id bigint NOT NULL,
    full_price bigint,
    purchase_price bigint,
    discount_percent numeric(5,2),
    available_amount integer NOT NULL,
    barcode character varying(100),
    characteristics jsonb,
    first_seen_at timestamp without time zone NOT NULL,
    last_seen_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.skus OWNER TO scraper;

--
-- Name: skus_id_seq; Type: SEQUENCE; Schema: public; Owner: scraper
--

CREATE SEQUENCE public.skus_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.skus_id_seq OWNER TO scraper;

--
-- Name: skus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: scraper
--

ALTER SEQUENCE public.skus_id_seq OWNED BY public.skus.id;


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: ecommerce_categories id; Type: DEFAULT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.ecommerce_categories ALTER COLUMN id SET DEFAULT nextval('public.ecommerce_categories_id_seq'::regclass);


--
-- Name: ecommerce_offers id; Type: DEFAULT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.ecommerce_offers ALTER COLUMN id SET DEFAULT nextval('public.ecommerce_offers_id_seq'::regclass);


--
-- Name: ecommerce_price_history id; Type: DEFAULT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.ecommerce_price_history ALTER COLUMN id SET DEFAULT nextval('public.ecommerce_price_history_id_seq'::regclass);


--
-- Name: ecommerce_products id; Type: DEFAULT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.ecommerce_products ALTER COLUMN id SET DEFAULT nextval('public.ecommerce_products_id_seq'::regclass);


--
-- Name: ecommerce_sellers id; Type: DEFAULT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.ecommerce_sellers ALTER COLUMN id SET DEFAULT nextval('public.ecommerce_sellers_id_seq'::regclass);


--
-- Name: price_history id; Type: DEFAULT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.price_history ALTER COLUMN id SET DEFAULT nextval('public.price_history_id_seq'::regclass);


--
-- Name: product_sellers id; Type: DEFAULT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.product_sellers ALTER COLUMN id SET DEFAULT nextval('public.product_sellers_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: raw_snapshots id; Type: DEFAULT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.raw_snapshots ALTER COLUMN id SET DEFAULT nextval('public.raw_snapshots_id_seq'::regclass);


--
-- Name: sellers id; Type: DEFAULT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.sellers ALTER COLUMN id SET DEFAULT nextval('public.sellers_id_seq'::regclass);


--
-- Name: skus id; Type: DEFAULT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.skus ALTER COLUMN id SET DEFAULT nextval('public.skus_id_seq'::regclass);


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: scraper
--

COPY public.categories (id, platform, title, title_ru, title_uz, parent_id, level, path_ids, path_titles, product_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ecommerce_categories; Type: TABLE DATA; Schema: public; Owner: scraper
--

COPY public.ecommerce_categories (id, platform, external_id, name, name_ru, name_uz, name_en, parent_id, level, path_ids, path_names, product_count, active_product_count, is_active, created_at, updated_at, attributes) FROM stdin;
\.


--
-- Data for Name: ecommerce_offers; Type: TABLE DATA; Schema: public; Owner: scraper
--

COPY public.ecommerce_offers (id, platform, external_id, product_id, seller_id, price, old_price, currency, discount_percent, is_available, stock_quantity, available_amount, variant_title, variant_attributes, barcode, shipping_cost, delivery_days, first_seen_at, last_seen_at, updated_at, scraped_at, characteristics) FROM stdin;
\.


--
-- Data for Name: ecommerce_price_history; Type: TABLE DATA; Schema: public; Owner: scraper
--

COPY public.ecommerce_price_history (id, offer_id, price, old_price, currency, discount_percent, available_amount, is_available, price_change, price_change_percent, recorded_at, is_significant_change, change_reason) FROM stdin;
\.


--
-- Data for Name: ecommerce_products; Type: TABLE DATA; Schema: public; Owner: scraper
--

COPY public.ecommerce_products (id, platform, external_id, title, title_normalized, title_ru, title_uz, title_en, description, category_id, seller_id, rating, review_count, order_count, view_count, is_available, total_available, min_price, max_price, currency, images, video_url, brand, model, sku, barcode, is_eco, is_adult, is_perishable, has_warranty, warranty_info, tags, search_keywords, first_seen_at, last_seen_at, updated_at, last_price_check, attributes, characteristics, raw_data) FROM stdin;
\.


--
-- Data for Name: ecommerce_sellers; Type: TABLE DATA; Schema: public; Owner: scraper
--

COPY public.ecommerce_sellers (id, platform, external_id, name, link, description, rating, review_count, order_count, total_products, is_official, is_verified, is_active, registration_date, profile_url, contact_info, first_seen_at, last_seen_at, updated_at, attributes, raw_data) FROM stdin;
\.


--
-- Data for Name: price_history; Type: TABLE DATA; Schema: public; Owner: scraper
--

COPY public.price_history (id, sku_id, product_id, full_price, purchase_price, discount_percent, available_amount, recorded_at, price_change, price_change_percent) FROM stdin;
\.


--
-- Data for Name: product_sellers; Type: TABLE DATA; Schema: public; Owner: scraper
--

COPY public.product_sellers (id, product_title_normalized, barcode, product_id, seller_id, min_price, max_price, first_seen_at, last_seen_at) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: scraper
--

COPY public.products (id, platform, title, title_normalized, title_ru, title_uz, category_id, seller_id, rating, review_count, order_count, is_available, total_available, description, photos, video_url, attributes, characteristics, tags, is_eco, is_adult, is_perishable, has_warranty, warranty_info, first_seen_at, last_seen_at, updated_at, raw_data) FROM stdin;
\.


--
-- Data for Name: raw_snapshots; Type: TABLE DATA; Schema: public; Owner: scraper
--

COPY public.raw_snapshots (id, platform, product_id, raw_json, file_path, fetched_at, processed, processed_at) FROM stdin;
\.


--
-- Data for Name: sellers; Type: TABLE DATA; Schema: public; Owner: scraper
--

COPY public.sellers (id, platform, title, link, description, rating, review_count, order_count, total_products, is_official, registration_date, account_id, first_seen_at, last_seen_at, updated_at, raw_data) FROM stdin;
\.


--
-- Data for Name: skus; Type: TABLE DATA; Schema: public; Owner: scraper
--

COPY public.skus (id, product_id, full_price, purchase_price, discount_percent, available_amount, barcode, characteristics, first_seen_at, last_seen_at, updated_at) FROM stdin;
\.


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: scraper
--

SELECT pg_catalog.setval('public.categories_id_seq', 1, false);


--
-- Name: ecommerce_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: scraper
--

SELECT pg_catalog.setval('public.ecommerce_categories_id_seq', 1, false);


--
-- Name: ecommerce_offers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: scraper
--

SELECT pg_catalog.setval('public.ecommerce_offers_id_seq', 1, false);


--
-- Name: ecommerce_price_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: scraper
--

SELECT pg_catalog.setval('public.ecommerce_price_history_id_seq', 1, false);


--
-- Name: ecommerce_products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: scraper
--

SELECT pg_catalog.setval('public.ecommerce_products_id_seq', 1, false);


--
-- Name: ecommerce_sellers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: scraper
--

SELECT pg_catalog.setval('public.ecommerce_sellers_id_seq', 1, false);


--
-- Name: price_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: scraper
--

SELECT pg_catalog.setval('public.price_history_id_seq', 1, false);


--
-- Name: product_sellers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: scraper
--

SELECT pg_catalog.setval('public.product_sellers_id_seq', 1, false);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: scraper
--

SELECT pg_catalog.setval('public.products_id_seq', 1, false);


--
-- Name: raw_snapshots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: scraper
--

SELECT pg_catalog.setval('public.raw_snapshots_id_seq', 1, false);


--
-- Name: sellers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: scraper
--

SELECT pg_catalog.setval('public.sellers_id_seq', 1, false);


--
-- Name: skus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: scraper
--

SELECT pg_catalog.setval('public.skus_id_seq', 1, false);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: ecommerce_categories ecommerce_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.ecommerce_categories
    ADD CONSTRAINT ecommerce_categories_pkey PRIMARY KEY (id);


--
-- Name: ecommerce_offers ecommerce_offers_pkey; Type: CONSTRAINT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.ecommerce_offers
    ADD CONSTRAINT ecommerce_offers_pkey PRIMARY KEY (id);


--
-- Name: ecommerce_price_history ecommerce_price_history_pkey; Type: CONSTRAINT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.ecommerce_price_history
    ADD CONSTRAINT ecommerce_price_history_pkey PRIMARY KEY (id);


--
-- Name: ecommerce_products ecommerce_products_pkey; Type: CONSTRAINT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.ecommerce_products
    ADD CONSTRAINT ecommerce_products_pkey PRIMARY KEY (id);


--
-- Name: ecommerce_sellers ecommerce_sellers_pkey; Type: CONSTRAINT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.ecommerce_sellers
    ADD CONSTRAINT ecommerce_sellers_pkey PRIMARY KEY (id);


--
-- Name: price_history price_history_pkey; Type: CONSTRAINT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_pkey PRIMARY KEY (id);


--
-- Name: product_sellers product_sellers_pkey; Type: CONSTRAINT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.product_sellers
    ADD CONSTRAINT product_sellers_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: raw_snapshots raw_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.raw_snapshots
    ADD CONSTRAINT raw_snapshots_pkey PRIMARY KEY (id);


--
-- Name: sellers sellers_pkey; Type: CONSTRAINT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.sellers
    ADD CONSTRAINT sellers_pkey PRIMARY KEY (id);


--
-- Name: skus skus_pkey; Type: CONSTRAINT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.skus
    ADD CONSTRAINT skus_pkey PRIMARY KEY (id);


--
-- Name: ecommerce_categories uq_category_platform_external; Type: CONSTRAINT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.ecommerce_categories
    ADD CONSTRAINT uq_category_platform_external UNIQUE (platform, external_id);


--
-- Name: ecommerce_offers uq_offer_platform_external; Type: CONSTRAINT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.ecommerce_offers
    ADD CONSTRAINT uq_offer_platform_external UNIQUE (platform, external_id);


--
-- Name: ecommerce_products uq_product_platform_external; Type: CONSTRAINT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.ecommerce_products
    ADD CONSTRAINT uq_product_platform_external UNIQUE (platform, external_id);


--
-- Name: ecommerce_sellers uq_seller_platform_external; Type: CONSTRAINT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.ecommerce_sellers
    ADD CONSTRAINT uq_seller_platform_external UNIQUE (platform, external_id);


--
-- Name: categories categories_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.categories(id);


--
-- Name: ecommerce_categories ecommerce_categories_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.ecommerce_categories
    ADD CONSTRAINT ecommerce_categories_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.ecommerce_categories(id);


--
-- Name: ecommerce_offers ecommerce_offers_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.ecommerce_offers
    ADD CONSTRAINT ecommerce_offers_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.ecommerce_products(id) ON DELETE CASCADE;


--
-- Name: ecommerce_offers ecommerce_offers_seller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.ecommerce_offers
    ADD CONSTRAINT ecommerce_offers_seller_id_fkey FOREIGN KEY (seller_id) REFERENCES public.ecommerce_sellers(id);


--
-- Name: ecommerce_price_history ecommerce_price_history_offer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.ecommerce_price_history
    ADD CONSTRAINT ecommerce_price_history_offer_id_fkey FOREIGN KEY (offer_id) REFERENCES public.ecommerce_offers(id) ON DELETE CASCADE;


--
-- Name: ecommerce_products ecommerce_products_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.ecommerce_products
    ADD CONSTRAINT ecommerce_products_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.ecommerce_categories(id);


--
-- Name: ecommerce_products ecommerce_products_seller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.ecommerce_products
    ADD CONSTRAINT ecommerce_products_seller_id_fkey FOREIGN KEY (seller_id) REFERENCES public.ecommerce_sellers(id);


--
-- Name: price_history price_history_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: price_history price_history_sku_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_sku_id_fkey FOREIGN KEY (sku_id) REFERENCES public.skus(id) ON DELETE CASCADE;


--
-- Name: product_sellers product_sellers_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.product_sellers
    ADD CONSTRAINT product_sellers_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: product_sellers product_sellers_seller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.product_sellers
    ADD CONSTRAINT product_sellers_seller_id_fkey FOREIGN KEY (seller_id) REFERENCES public.sellers(id);


--
-- Name: products products_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: products products_seller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_seller_id_fkey FOREIGN KEY (seller_id) REFERENCES public.sellers(id);


--
-- Name: skus skus_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: scraper
--

ALTER TABLE ONLY public.skus
    ADD CONSTRAINT skus_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 4FMyVCxg9gaXauIlxjCESDN6T9AenG3BVSFtDsX4QTvCttHtCBtbPjnJJpdvlOp

